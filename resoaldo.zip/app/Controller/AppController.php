<?php

/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
App::uses('Controller', 'Controller');
App::uses('CakeEmail', 'Network/Email');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

    public $components = array('Session', 'Auth' => array(
            'loginRedirect' => array('controller' => 'dashboard', 'action' => 'index'),
            'logoutRedirect' => array('controller' => 'users', 'action' => 'login'),
            'authError' => 'Para continuar por favor Inicie sesion'
    ));
    Public $helpers = array('Session', 'Js');
    private $appPermission = array();
    public $roles = array('admin' => 'Administrador', 'runner' => 'Corredor');

    public function beforeFilter() {
        if (!$this->request->is('ajax') && $this->name != 'CakeError' && $this->here != Router::url(array('controller' => 'users', 'action' => 'login'))) {
            $this->Session->write('Auth.redirect', $this->here);
        }
        $usuario = $this->Auth->user();

        $this->setUpPermission();
        $this->applyACL();
        $this->set('roles', $this->roles);
    }

    private function applyACL() {
        $controller = strtolower($this->request->params['controller']);
        $action = strtolower($this->request->params['action']);

        $isAllow = $this->isAllow($controller, $action);
        switch ($isAllow) {
            case false:
                $this->rejectRequest();
                break;
            case true:
                break;
        }
    }

    private function rejectRequest() {
        $this->Session->setFlash('Usted no tiene permisos para acceder a esta seccion');
        $this->redirect($this->referer());
    }

    public function isAllow($controller, $action) {
        if (isset($this->request->data['allow']) && $this->request->data['allow'])
            return true;
        $role = $this->Auth->user('role');
        if ($role != null) {
            $permission = $this->appPermission[$role];
            if (array_search('*', $permission['basic']) !== false)
                return true;
            if (array_search($controller, $permission['basic']) !== false)
                return true;
            if (array_search($controller . "/" . $action, $permission['basic']) !== false)
                return true;

            if (isset($permission['strict'])) {
                $refer = substr($this->referer(), strlen(Router::url('/', true)));
                $refer = implode('/', array_slice(explode('/', $refer), 0, 2));
                foreach ($permission['strict'] as $key => $exception) {
                    $key = array_search($refer, $exception);
                    if ($key !== false) {
                        if ($key == $controller || $key == ($controller . "/" . $action ))
                            return true;
                    }
                }
            }

            return false;
        } else {
            return true;
        }
    }

    public function setUpPermission() {
//permission for superadministrador 
        $this->appPermission['admin']['basic'][] = '*';

//permisos para corredores
        $this->appPermission['runner']['basic'][] = 'events';
        $this->appPermission['catalogo']['basic'][] = 'user/edit';
        $this->appPermission['catalogo']['basic'][] = 'users/login';
        $this->appPermission['catalogo']['basic'][] = 'users/logout';
    }

    protected function updateImage($data, $destenyPath, $filename) {
        mkdir($destenyPath, 0775, true);
        if (isset($data['name'])) {
            $extencion = pathinfo($data['name'], PATHINFO_EXTENSION);
            move_uploaded_file($data['tmp_name'], $destenyPath . $filename . '.' . $extencion);
        }
    }

    protected function deleteImage($filename) {
        unlink($filename);
    }

}

?>