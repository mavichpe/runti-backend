<?php

App::uses('AppController', 'Controller');

/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class DashboardController extends AppController {

    public function beforeFilter() {
        parent::beforeFilter();
    }

    public function index() {
        
    }

}
